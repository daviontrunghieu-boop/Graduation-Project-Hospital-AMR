#!/usr/bin/env python3
from __future__ import annotations

import json
import os
from pathlib import Path

from nicegui import ui

try:
    from wed_server.web.appointments import (
        AppointmentStore,
        RobotStateStore,
        SymptomRoomRuleStore,
        format_appointments,
        format_symptom_room_rules,
    )
except ModuleNotFoundError:
    from appointments import (
        AppointmentStore,
        RobotStateStore,
        SymptomRoomRuleStore,
        format_appointments,
        format_symptom_room_rules,
    )


ACCOUNT_STORE_PATH = Path(
    os.getenv(
        "ROBOT_HOSPITAL_ACCOUNT_PATH",
        Path(__file__).resolve().parents[1] / "patient_accounts.json",
    )
)
ROBOT_PATIENT_PROFILE_PATH = Path(
    os.getenv(
        "ROBOT_HOSPITAL_ROBOT_PATIENT_PATH",
        Path(__file__).resolve().parents[1] / "robot_patient_profiles.json",
    )
)

store = AppointmentStore()
robot_store = RobotStateStore()
symptom_rule_store = SymptomRoomRuleStore()


def list_registered_patient_phones() -> list[str]:
    try:
        if not ACCOUNT_STORE_PATH.exists():
            return []
        data = json.loads(ACCOUNT_STORE_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        cleaned = sorted({str(phone).strip() for phone in data if str(phone).strip()})
        return cleaned
    except (OSError, json.JSONDecodeError):
        return []


def load_robot_patient_profiles() -> dict[str, dict]:
    try:
        if not ROBOT_PATIENT_PROFILE_PATH.exists():
            return {}
        data = json.loads(ROBOT_PATIENT_PROFILE_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {}
        patients = data.get("patients", {})
        if isinstance(patients, dict):
            return patients
        return data
    except (OSError, json.JSONDecodeError):
        return {}


def format_robot_patient_profiles(profiles: dict[str, dict]) -> list[dict[str, str | int]]:
    rows: list[dict[str, str | int]] = []
    for phone, profile in profiles.items():
        appointment = profile.get("latest_appointment", {})
        if not isinstance(appointment, dict):
            appointment = {}
        rows.append(
            {
                "patient_name": str(profile.get("patient_name", "")),
                "phone": str(profile.get("phone", phone)),
                "face_capture_count": int(profile.get("face_capture_count", 0) or 0),
                "latest_capture_at": str(profile.get("latest_capture_at", "")),
                "queue_number": str(appointment.get("queue_number", "")),
                "department": str(appointment.get("department", "")),
                "room_label": str(appointment.get("room_label", "")),
                "appointment_date": str(appointment.get("appointment_date", "")),
                "appointment_time": str(appointment.get("appointment_time", "")),
                "updated_at": str(profile.get("updated_at", "")),
            }
        )
    rows.sort(key=lambda row: (str(row["updated_at"]), str(row["phone"])), reverse=True)
    return rows


def build_admin_dashboard() -> None:
    ui.add_head_html(
        """
        <style>
            body {
                margin: 0;
                background:
                    radial-gradient(circle at top left, rgba(14, 165, 233, 0.18), transparent 25%),
                    linear-gradient(135deg, #e0f2fe 0%, #f8fafc 42%, #ecfeff 100%);
            }
            .admin-shell {
                width: 100%;
                max-width: 1680px;
            }
            .admin-stat-card {
                border-radius: 28px;
                background: rgba(255, 255, 255, 0.92);
                box-shadow: 0 22px 40px rgba(15, 23, 42, 0.10);
            }
            .admin-panel {
                border-radius: 32px;
                background: rgba(255, 255, 255, 0.94);
                box-shadow: 0 26px 48px rgba(15, 23, 42, 0.12);
            }
        </style>
        """
    )

    state = robot_store.load()

    def battery_tone(level: int) -> str:
        if level >= 70:
            return "text-emerald-600"
        if level >= 40:
            return "text-amber-500"
        return "text-rose-500"

    def status_tone(status: str) -> str:
        mapping = {
            "Sẵn sàng": "bg-emerald-100 text-emerald-700",
            "Đang dẫn bệnh nhân": "bg-cyan-100 text-cyan-700",
            "Đang sạc": "bg-amber-100 text-amber-700",
            "Tạm dừng": "bg-rose-100 text-rose-700",
            "Bảo trì": "bg-slate-200 text-slate-700",
        }
        return mapping.get(status, "bg-slate-100 text-slate-700")

    with ui.column().classes("w-full items-center px-6 py-8 md:px-10 xl:px-16"):
        with ui.column().classes("admin-shell gap-6"):
            with ui.row().classes("items-center justify-between gap-4 max-[900px]:flex-col max-[900px]:items-start"):
                with ui.column().classes("gap-2"):
                    ui.label("Admin Robot AURORA").classes("text-4xl font-black text-slate-900")
                    ui.label("Trang quản trị nhận dữ liệu từ web đặt lịch và quản lý robot hỗ trợ.").classes(
                        "text-base text-slate-600"
                    )
                with ui.row().classes("gap-3"):
                    ui.button("Mở trang web bệnh nhân", on_click=lambda: ui.navigate.to("/")).props("outline no-caps").classes(
                        "rounded-full border-cyan-500 px-5 py-3 font-bold text-cyan-600"
                    )
                    ui.button("Làm mới", on_click=lambda: ui.navigate.to("/admin")).props("unelevated no-caps icon=refresh").classes(
                        "rounded-full bg-cyan-500 px-5 py-3 font-bold text-white"
                    )

            with ui.row().classes("w-full gap-5 max-[1000px]:flex-col"):
                with ui.card().classes("admin-stat-card flex-1 p-6"):
                    ui.label("Lịch hẹn từ web").classes("text-sm font-bold uppercase tracking-[0.2em] text-cyan-600")
                    ui.label(str(store.count_appointments())).classes("mt-3 text-4xl font-black text-slate-900")
                    ui.label("Các lịch bệnh nhân đặt trên web sẽ tự động hiển thị tại admin.").classes(
                        "mt-2 text-sm leading-6 text-slate-600"
                    )
                with ui.card().classes("admin-stat-card flex-1 p-6"):
                    ui.label("Tài khoản bệnh nhân").classes("text-sm font-bold uppercase tracking-[0.2em] text-cyan-600")
                    ui.label(str(len(list_registered_patient_phones()))).classes("mt-3 text-4xl font-black text-slate-900")
                    ui.label("Danh sách số điện thoại đã tạo tài khoản để admin đối soát.").classes(
                        "mt-2 text-sm leading-6 text-slate-600"
                    )
                with ui.card().classes("admin-stat-card flex-1 p-6"):
                    ui.label("Robot hiện tại").classes("text-sm font-bold uppercase tracking-[0.2em] text-cyan-600")
                    ui.label(state.robot_name).classes("mt-3 text-4xl font-black text-slate-900")
                    ui.label(state.status).classes(
                        f"mt-3 inline-flex rounded-full px-4 py-2 text-sm font-black {status_tone(state.status)}"
                    )

            with ui.row().classes("w-full items-start gap-6 max-[1200px]:flex-col"):
                with ui.card().classes("admin-panel w-[440px] max-w-full shrink-0 p-7"):
                    ui.label("Quản lý robot").classes("text-2xl font-black text-slate-900")
                    ui.label("Cập nhật thông số robot để đội vận hành theo dõi trên một trang riêng.").classes(
                        "mt-2 text-sm leading-6 text-slate-600"
                    )

                    robot_name_input = ui.input("Tên robot", value=state.robot_name).props("outlined dense").classes("mt-5 w-full")
                    robot_status_input = ui.select(
                        ["Sẵn sàng", "Đang dẫn bệnh nhân", "Đang sạc", "Tạm dừng", "Bảo trì"],
                        value=state.status,
                        label="Trạng thái",
                    ).props("outlined dense options-dense").classes("w-full")
                    robot_zone_input = ui.input("Khu vực hiện tại", value=state.current_zone).props("outlined dense").classes("w-full")
                    robot_battery_input = ui.number("Pin (%)", value=state.battery_level, min=0, max=100).props("outlined dense").classes(
                        "w-full"
                    )
                    queue_limit_input = ui.number(
                        "Số bệnh nhân robot có thể nhận",
                        value=state.queue_limit,
                        min=1,
                        max=99,
                    ).props("outlined dense").classes("w-full")
                    auto_dispatch_switch = ui.switch("Tự động nhận bệnh nhân mới", value=state.auto_dispatch).classes("mt-2")
                    note_input = ui.textarea("Ghi chú vận hành", value=state.note).props("outlined").classes("w-full")

                    def save_robot_state() -> None:
                        robot_store.update(
                            robot_name=str(robot_name_input.value or ""),
                            status=str(robot_status_input.value or ""),
                            current_zone=str(robot_zone_input.value or ""),
                            battery_level=int(robot_battery_input.value or 0),
                            queue_limit=int(queue_limit_input.value or 1),
                            auto_dispatch=bool(auto_dispatch_switch.value),
                            note=str(note_input.value or ""),
                        )
                        ui.notify("Đã lưu trạng thái robot.", color="positive")
                        ui.navigate.to("/admin")

                    ui.button("Lưu robot", on_click=save_robot_state).props("unelevated no-caps").classes(
                        "mt-4 w-full rounded-full bg-cyan-500 py-3 font-bold text-white"
                    )

                with ui.column().classes("min-w-0 flex-1 gap-6"):
                    with ui.card().classes("admin-panel p-7"):
                        ui.label("Tình trạng robot").classes("text-2xl font-black text-slate-900")
                        with ui.grid(columns=2).classes("mt-5 w-full gap-4 max-[800px]:grid-cols-1"):
                            with ui.card().classes("rounded-3xl bg-slate-950 p-5 text-white shadow-none"):
                                ui.label("Khu vực hiện tại").classes("text-sm uppercase tracking-[0.18em] text-cyan-200")
                                ui.label(state.current_zone).classes("mt-3 text-2xl font-black")
                            with ui.card().classes("rounded-3xl bg-white p-5 shadow-none ring-1 ring-slate-200"):
                                ui.label("Pin").classes("text-sm uppercase tracking-[0.18em] text-slate-500")
                                ui.label(f"{state.battery_level}%").classes(f"mt-3 text-3xl font-black {battery_tone(state.battery_level)}")
                            with ui.card().classes("rounded-3xl bg-white p-5 shadow-none ring-1 ring-slate-200"):
                                ui.label("Giới hạn tiếp nhận").classes("text-sm uppercase tracking-[0.18em] text-slate-500")
                                ui.label(str(state.queue_limit)).classes("mt-3 text-3xl font-black text-slate-900")
                            with ui.card().classes("rounded-3xl bg-white p-5 shadow-none ring-1 ring-slate-200"):
                                ui.label("Tự động điều phối").classes("text-sm uppercase tracking-[0.18em] text-slate-500")
                                ui.label("Bật" if state.auto_dispatch else "Tắt").classes("mt-3 text-3xl font-black text-slate-900")
                        ui.label(state.note or "Chưa có ghi chú vận hành.").classes("mt-5 text-base leading-7 text-slate-600")
                        ui.label(f"Cập nhật lần cuối: {state.updated_at}").classes("mt-2 text-sm font-semibold text-cyan-700")

                    with ui.card().classes("admin-panel p-7"):
                        ui.label("Dữ liệu web gửi sang admin").classes("text-2xl font-black text-slate-900")
                        ui.label("Mỗi lịch hẹn đặt trên web sẽ được đọc từ cùng cơ sở dữ liệu ở đây.").classes(
                            "mt-2 text-sm leading-6 text-slate-600"
                        )
                        appointments_table_admin = ui.table(
                            columns=[
                                {"name": "id", "label": "STT", "field": "id", "align": "left"},
                                {"name": "patient_name", "label": "Bệnh nhân", "field": "patient_name", "align": "left"},
                                {"name": "phone", "label": "Điện thoại", "field": "phone", "align": "left"},
                                {"name": "department", "label": "Khoa", "field": "department", "align": "left"},
                                {"name": "appointment_date", "label": "Ngày khám", "field": "appointment_date", "align": "left"},
                                {"name": "appointment_time", "label": "Giờ khám", "field": "appointment_time", "align": "left"},
                                {"name": "symptoms", "label": "Triệu chứng", "field": "symptoms", "align": "left"},
                                {"name": "created_at", "label": "Tạo lúc", "field": "created_at", "align": "left"},
                            ],
                            rows=format_appointments(store.list_appointments(limit=100)),
                            row_key="id",
                        ).classes("mt-5 w-full overflow-hidden rounded-3xl bg-white")
                        appointments_table_admin.props("flat bordered wrap-cells")

                    with ui.card().classes("admin-panel p-7"):
                        ui.label("Danh sách tài khoản").classes("text-2xl font-black text-slate-900")
                        accounts_table_admin = ui.table(
                            columns=[{"name": "phone", "label": "Số điện thoại", "field": "phone", "align": "left"}],
                            rows=[{"phone": phone} for phone in list_registered_patient_phones()],
                            row_key="phone",
                        ).classes("mt-5 w-full overflow-hidden rounded-3xl bg-white")
                        accounts_table_admin.props("flat bordered")

                    with ui.card().classes("admin-panel p-7"):
                        ui.label("Hồ sơ khuôn mặt cho robot").classes("text-2xl font-black text-slate-900")
                        ui.label(
                            "Mỗi lần bệnh nhân chụp ảnh trong web, hệ thống sẽ lưu hồ sơ chung để web admin theo dõi và robot dùng lại khi xác minh."
                        ).classes("mt-2 text-sm leading-6 text-slate-600")
                        robot_patient_table = ui.table(
                            columns=[
                                {"name": "patient_name", "label": "Bệnh nhân", "field": "patient_name", "align": "left"},
                                {"name": "phone", "label": "Điện thoại", "field": "phone", "align": "left"},
                                {"name": "face_capture_count", "label": "Số ảnh", "field": "face_capture_count", "align": "left"},
                                {"name": "latest_capture_at", "label": "Chụp gần nhất", "field": "latest_capture_at", "align": "left"},
                                {"name": "queue_number", "label": "STT", "field": "queue_number", "align": "left"},
                                {"name": "department", "label": "Khoa", "field": "department", "align": "left"},
                                {"name": "room_label", "label": "Phòng", "field": "room_label", "align": "left"},
                                {"name": "appointment_date", "label": "Ngày khám", "field": "appointment_date", "align": "left"},
                                {"name": "appointment_time", "label": "Giờ", "field": "appointment_time", "align": "left"},
                            ],
                            rows=format_robot_patient_profiles(load_robot_patient_profiles()),
                            row_key="phone",
                        ).classes("mt-5 w-full overflow-hidden rounded-3xl bg-white")
                        robot_patient_table.props("flat bordered wrap-cells")

                    with ui.card().classes("admin-panel p-7"):
                        ui.label("Bảng triệu chứng - phòng khám").classes("text-2xl font-black text-slate-900")
                        ui.label(
                            "Thêm các dòng ánh xạ để quy đổi triệu chứng sang phòng khám. "
                            "Mỗi dòng là một quy tắc, bạn có thể tạo nhiều dòng cho cùng một triệu chứng."
                        ).classes("mt-2 text-sm leading-6 text-slate-600")

                        symptom_input = ui.textarea("Triệu chứng / từ khóa").props("outlined").classes("mt-5 w-full")
                        department_input = ui.input("Khoa khám").props("outlined dense").classes("w-full")
                        room_input = ui.input("Phòng khám").props("outlined dense").classes("w-full")
                        note_input = ui.textarea("Ghi chú").props("outlined").classes("w-full")
                        delete_rule_id_input = ui.number("ID cần xóa", min=1, step=1).props("outlined dense").classes("w-full")

                        symptom_rules_table = ui.table(
                            columns=[
                                {"name": "id", "label": "ID", "field": "id", "align": "left"},
                                {"name": "symptom_keywords", "label": "Triệu chứng", "field": "symptom_keywords", "align": "left"},
                                {"name": "department", "label": "Khoa", "field": "department", "align": "left"},
                                {"name": "room_label", "label": "Phòng khám", "field": "room_label", "align": "left"},
                                {"name": "note", "label": "Ghi chú", "field": "note", "align": "left"},
                            ],
                            rows=format_symptom_room_rules(symptom_rule_store.list_rules()),
                            row_key="id",
                        ).classes("mt-5 w-full overflow-hidden rounded-3xl bg-white")
                        symptom_rules_table.props("flat bordered wrap-cells")

                        def refresh_symptom_rules_table() -> None:
                            symptom_rules_table.rows = format_symptom_room_rules(symptom_rule_store.list_rules())
                            symptom_rules_table.update()

                        def save_symptom_rule() -> None:
                            try:
                                symptom_rule_store.create_rule(
                                    symptom_keywords=str(symptom_input.value or ""),
                                    department=str(department_input.value or ""),
                                    room_label=str(room_input.value or ""),
                                    note=str(note_input.value or ""),
                                )
                            except ValueError as error:
                                ui.notify(str(error), color="negative")
                                return
                            symptom_input.set_value("")
                            department_input.set_value("")
                            room_input.set_value("")
                            note_input.set_value("")
                            refresh_symptom_rules_table()
                            ui.notify("Đã thêm mapping triệu chứng - phòng khám.", color="positive")

                        def delete_symptom_rule() -> None:
                            rule_id = int(delete_rule_id_input.value or 0)
                            if rule_id <= 0:
                                ui.notify("Vui lòng nhập ID hợp lệ để xóa.", color="negative")
                                return
                            if not symptom_rule_store.delete_rule(rule_id):
                                ui.notify(f"Không tìm thấy dòng có ID {rule_id}.", color="negative")
                                return
                            delete_rule_id_input.set_value(None)
                            refresh_symptom_rules_table()
                            ui.notify(f"Đã xóa mapping ID {rule_id}.", color="positive")

                        with ui.row().classes("mt-4 w-full gap-3 max-[800px]:flex-col"):
                            ui.button("Lưu mapping", on_click=save_symptom_rule).props("unelevated no-caps").classes(
                                "rounded-full bg-cyan-500 px-5 py-3 font-bold text-white"
                            )
                            ui.button("Xóa theo ID", on_click=delete_symptom_rule).props("outline no-caps").classes(
                                "rounded-full border-rose-300 px-5 py-3 font-bold text-rose-600"
                            )


@ui.page("/admin")
def admin_page() -> None:
    build_admin_dashboard()

if __name__ in {"__main__", "__mp_main__"}:
    ui.run(
        host=os.getenv("NICEGUI_HOST", "0.0.0.0"),
        port=int(os.getenv("NICEGUI_PORT", "8081")),
        title="Robot Hospital Booking",
        show=True,
        reload=False,
    )