import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    
    # 1. Node Serial Bridge (Kết nối Arduino Mega)
    # File này nằm trong package my_robot_bringup
    serial_bridge_node = Node(
        package='my_robot_bringup',
        executable='serial_bridge_node.py', #   Tên file bạn đã chmod +x
        name='serial_bridge',
        output='screen',
        parameters=[{'port': '/dev/ttyACM0', 'baudrate': 115200}]
    )

    # 2. Node Voice Control (Hỗ trợ người mù - Deepgram)
    # File này nằm trong package voice_control
    voice_control_node = Node(
        package='voice_control',
        executable='voice_nav_node.py', 
        name='voice_navigation',
        output='screen'
    )

    # 3. Node Né vật cản (MPPI/Thestar)
    # Giả sử bạn để trong package my_robot_bringup
    obstacle_avoidance_node = Node(
        package='my_robot_bringup',
        executable='nav2_huy.launch.py', # Tên executable thuật toán của bạn
        name='mppi_navigator',
        output='screen'
    )

    # 4. Gọi file Launch của Lidar (Sử dụng Lidar thật)
    # Thay 'ldlidar_stl_ros2' bằng package Lidar bạn đang dùng
    lidar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('rplidar_ros'), 'launch'),
            'rplidar_a1_launch.py'])
    )

    return LaunchDescription([
        serial_bridge_node,
        voice_control_node,
        obstacle_avoidance_node,
        lidar_launch
    ])