#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose

import asyncio
import json
import websockets
import pyaudio
import requests
from vieneu import Vieneu
import re
import os
import threading

# 🔑 API KEY CỦA BẠN (DEEPGRAM - Dùng cho LẮNG NGHE STT)
DEEPGRAM_API_KEY = "a6fea495d7536bac430294dc1fb71e10c710cab9"

class VoiceNavNode(Node):
    def __init__(self):
        super().__init__('voice_nav_node')
        
        # 1. Action Client để điều hướng Nav2
        self._nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        
        # 2. Khởi tạo VieNeu TTS (Chế độ turbo tối ưu chạy siêu nhẹ)
        self.tts = Vieneu(mode="turbo")
        
        # 3. Đường dẫn file dữ liệu (Đã set tuyệt đối)
        self.data_path = "/home/hieu/ros2_ws/src/my_robot_web_config/robot_web_interface/user_information/patient_information.json"
        
        self.get_logger().info("🤖 Robot Hospital Voice đã sẵn sàng (Deepgram STT + VieNeu TTS + Nav2)...")
        
        # Lời chào khi khởi động (Đưa vào luồng riêng)
        threading.Thread(target=self.speak, args=("Hệ thống đã sẵn sàng. Vui lòng đọc số thứ tự để tôi dẫn đường.",), daemon=True).start()

    def speak(self, text):
        """Hàm giúp Robot phát ra tiếng nói Tiếng Việt tự nhiên bằng VieNeu-TTS"""
        self.get_logger().info(f"Robot nói (TTS): {text}")
        try:
            audio_data = self.tts.infer(text=text)
            temp_file = "/tmp/robot_speech.wav"
            self.tts.save(audio_data, temp_file)
            
            # Phát âm thanh ra loa công cộng
            os.system(f"aplay -q {temp_file}")
            
        except Exception as e:
            self.get_logger().error(f"❌ Lỗi khi xử lý hoặc phát giọng nói VieNeu-TTS: {e}")

    def load_patient_data(self):
        """Đọc file JSON mỗi khi có lệnh để đảm bảo dữ liệu mới nhất"""
        if not os.path.exists(self.data_path):
            self.get_logger().error(f"Lỗi: Không tìm thấy file tại {self.data_path}")
            return None
        
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.get_logger().error(f"Lỗi đọc JSON: {e}")
            return None

    def process_command(self, transcript):
        """Xử lý văn bản nhận diện được từ Deepgram"""
        text = transcript.lower()
        
        # --- ĐÃ SỬA LỖI BUG LOGIC Ở ĐÂY ---
        # BỘ DỊCH ÉP CHỮ THÀNH SỐ (Tiếng Việt) - Ưu tiên cụm từ ghép dài thay thế trước!
        word_to_num = {
            "mười lăm": "15", "mười bốn": "14", "mười ba": "13", "mười hai": "12", "mười một": "11",
            "mười": "10", "chín": "9", "tám": "8", "bảy": "7", "sáu": "6",
            "năm": "5", "bốn": "4", "ba": "3", "hai": "2", "một": "1", "không": "0"
        }
        
        for word, num in word_to_num.items():
            text = re.sub(rf'\b{word}\b', num, text)

        self.get_logger().info(f"🎤 Robot nghe thấy (đã bóc tách số): {text}")

        # Tìm TẤT CẢ các số trong câu nói
        numbers = re.findall(r'\d+', text)
        if not numbers:
            return

        data = self.load_patient_data()
        if not data:
            self.speak("Xin lỗi, hệ thống không thể kết nối với dữ liệu bệnh nhân.")
            return

        queue_index = data.get("queue_index", {})
        found_patient = None
        
        for num in numbers:
            if num in queue_index:
                found_patient = queue_index[num]
                break
                
        if found_patient:
            name = found_patient.get("patient_name", "bệnh nhân")
            room = found_patient.get("room_label", "phòng khám")
            pose_dict = found_patient.get("destination_pose", {})
            
            if pose_dict.get("configured", False):
                self.speak(f"Đã xác nhận số thứ tự của bệnh nhân {name}. Xin mời đi theo tôi đến phòng {room}.")
                self.send_navigation_goal(pose_dict)
            else:
                self.speak(f"Xin lỗi bệnh nhân {name}, tọa độ của phòng {room} chưa được cấu hình trên hệ thống.")
        else:
            self.speak("Tôi không tìm thấy số thứ tự này trên hệ thống, vui lòng đọc lại.")

    def send_navigation_goal(self, pose_dict):
        """Gửi tọa độ mục tiêu xuống Nav2 và chờ phản hồi"""
        if not self._nav_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error("Nav2 Action Server không phản hồi!")
            self.speak("Hệ thống di chuyển định vị đang gặp sự cố, vui lòng kiểm tra lại.")
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = "map"
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        
        goal_msg.pose.pose.position.x = float(pose_dict.get("x", 0.0))
        goal_msg.pose.pose.position.y = float(pose_dict.get("y", 0.0))
        goal_msg.pose.pose.position.z = float(pose_dict.get("z", 0.0))
        
        goal_msg.pose.pose.orientation.x = 0.0
        goal_msg.pose.pose.orientation.y = 0.0
        goal_msg.pose.pose.orientation.z = 0.0
        goal_msg.pose.pose.orientation.w = float(pose_dict.get("w", 1.0))

        self.get_logger().info(f"🚀 Đang gửi lệnh di chuyển đến: X={goal_msg.pose.pose.position.x}, Y={goal_msg.pose.pose.position.y}")
        
        self._send_goal_future = self._nav_client.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        """Nhận phản hồi từ Nav2"""
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("❌ Nav2 ĐÃ TỪ CHỐI mục tiêu di chuyển!")
            self.speak("Điểm đến này không hợp lệ hoặc đang có vật cản lớn chặn đường.")
            return
        
        self.get_logger().info("✅ Nav2 đã CHẤP NHẬN. Bắt đầu lăn bánh...")
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        """Báo cáo khi tới đích"""
        self.get_logger().info("🎉 Đã đến nơi!")
        self.speak("Chúng ta đã đến nơi rồi. Chúc bạn có một buổi khám bệnh thuận lợi.")

    async def start_listening(self):
        """Khởi động luồng lắng nghe liên tục qua Deepgram WebSocket"""
        URL = "wss://api.deepgram.com/v1/listen?language=vi&model=nova-2&smart_format=true&interim_results=false&endpointing=300&keepalive=true&encoding=linear16&sample_rate=16000&channels=1"
        
        try:
            async with websockets.connect(URL, extra_headers={"Authorization": f"Token {DEEPGRAM_API_KEY}"}) as ws:
                
                audio = pyaudio.PyAudio()
                stream = audio.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=4000)
                
                async def send_audio():
                    while True:
                        try:
                            data = stream.read(4000, exception_on_overflow=False)
                            await ws.send(data)
                            await asyncio.sleep(0.01)
                        except Exception as e:
                            self.get_logger().error(f"Lỗi gửi audio: {e}")
                            break

                async def receive_text():
                    async for message in ws:
                        data = json.loads(message)
                        if data.get("type") == "Results":
                            alternatives = data.get("channel", {}).get("alternatives", [])
                            if alternatives:
                                transcript = alternatives[0].get("transcript", "")
                                if transcript.strip():
                                    threading.Thread(target=self.process_command, args=(transcript,), daemon=True).start()

                self.get_logger().info("👂 Đang lắng nghe âm thanh từ môi trường...")
                await asyncio.gather(send_audio(), receive_text())
                
        except Exception as e:
            self.get_logger().error(f"Lỗi kết nối Deepgram: {e}")
            threading.Thread(target=self.speak, args=("Không thể kết nối với hệ thống nhận diện giọng nói.",), daemon=True).start()

def main(args=None):
    rclpy.init(args=args)
    node = VoiceNavNode()
    
    # Chạy ROS2 Spin trong luồng phụ
    spin_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    spin_thread.start()
    
    # Vòng lặp Asyncio chính
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(node.start_listening())
    except KeyboardInterrupt:
        node.get_logger().info("🛑 Đã dừng tiến trình voice_nav_node.")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()