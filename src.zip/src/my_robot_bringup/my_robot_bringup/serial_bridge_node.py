#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial

class SerialBridge(Node):
    def __init__(self):
        super().__init__('serial_bridge')
        
        # Cấu hình cổng kết nối Arduino Mega
        # Bạn nên kiểm tra bằng lệnh 'ls /dev/ttyACM*' để xác định đúng cổng
        self.port = '/dev/ttyACM0' 
        self.baudrate = 115200
        
        try:
            self.ser = serial.Serial(self.port, self.baudrate, timeout=0.1)
            self.get_logger().info(f"HARDWARE: Kết nối thành công Arduino tại {self.port}")
        except Exception as e:
            self.get_logger().error(f"HARDWARE: Lỗi kết nối Serial: {e}")

        # Subscribe topic từ bộ điều khiển né vật cản/giọng nói
        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel', # Topic mà MPPI/Thestar hoặc Voice đang publish vào [cite: 1, 2]
            self.cmd_vel_callback,
            10)

    def cmd_vel_callback(self, msg):
        v = msg.linear.x
        w = msg.angular.z
        
        # Đóng gói theo giao thức <v,w>
        packet = f"<{v:.2f},{w:.2f}>\n"
        
        try:
            self.ser.write(packet.encode('utf-8'))
        except Exception as e:
            self.get_logger().error(f"Lỗi gửi lệnh xuống Arduino: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = SerialBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()